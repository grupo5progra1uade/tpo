profesores = {
    1: {"nombre": "Maria", "apellido": "Gonzalez", "materia": "Matematica"},
    2: {"nombre": "Juan",  "apellido": "Perez",     "materia": "Historia"},
    3: {"nombre": "Luis", "apellido": "Ramirez",   "materia": "Literatura"}
    #agrego los demas profesores aca
}